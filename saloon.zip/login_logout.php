<?php
mysql_connect("localhost","root","") or die("couldn't connect to SQL server");
mysql_select_db("login_logout")or dir("couldn't select DB");
?>